document.getElementById('weather-form').addEventListener('submit', function(event) {
  event.preventDefault();
  const city = document.getElementById('city-input').value;
  fetchWeather(city);
});

function fetchWeather(city) {
  fetch(`/api/weather?city=${city}`)
    .then(response => response.json())
    .then(data => displayWeather(data))
    .catch(error => console.error('Error fetching weather data:', error));
}

function displayWeather(weather) {
  document.getElementById('weather-name').textContent = weather.name;
  document.getElementById('weather-temp').textContent = `Temperature: ${weather.main.temp}°C`;
  document.getElementById('weather-humidity').textContent = `Humidity: ${weather.main.humidity}%`;
  document.getElementById('weather-condition').textContent = `Condition: ${weather.weather[0].description}`;

  document.getElementById('weather-display').style.display = 'block';
}
