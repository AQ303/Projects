// Carousel functionality
let slideIndex = 0;

function showSlides(className) {
  const slides = document.querySelectorAll(`.${className} .carousel-slide img`);
  
  // Hide all slides
  slides.forEach(slide => {
    slide.style.display = 'none';
  });
  
  // Increment index and reset if out of bounds
  slideIndex++;
  if (slideIndex > slides.length) { slideIndex = 1; }
  
  // Display current slide
  slides[slideIndex - 1].style.display = 'block';
  
  // Change slide every 3 seconds
  setTimeout(() => showSlides(className), 3000);
}

// Next/previous controls for carousel
function nextSlide(className) {
  slideIndex++;
  showSlides(className);
}

function prevSlide(className) {
  slideIndex--;
  showSlides(className);
}

// Initial call to start carousel
document.addEventListener('DOMContentLoaded', () => {
  showSlides('new-arrivals');
  showSlides('testimonials');
});
